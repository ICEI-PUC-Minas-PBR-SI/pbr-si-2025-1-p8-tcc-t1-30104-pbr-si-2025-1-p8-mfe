export type TRegisterHandler = (name?: string, email?: string, password?: string) => void;
