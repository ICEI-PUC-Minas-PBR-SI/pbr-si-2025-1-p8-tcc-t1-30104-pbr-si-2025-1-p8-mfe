import auth0Plugin from "@/plugins/Auth0Plugin.ts";

export {
  auth0Plugin
}
