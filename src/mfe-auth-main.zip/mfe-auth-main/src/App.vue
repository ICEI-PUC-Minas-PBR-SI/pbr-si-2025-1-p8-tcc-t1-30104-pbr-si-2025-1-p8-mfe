<script lang="ts" setup>
import LoginView from '@/views/LoginView.vue';
</script>

<template>
  <login-view />
</template>

<style lang="scss" scoped></style>
